

<?php $__env->startSection('title', 'Menu - Restaurantly'); ?>

<?php $__env->startSection('body-class', 'menu-page'); ?>

<?php $__env->startSection('content'); ?>

<!-- Menu Section -->
<section id="menu" class="menu section" style="padding-top: 100px;">

  <!-- Section Title -->
  <div class="container section-title" data-aos="fade-up">
    <h2>MENU</h2>
    <p>Check Our Tasty Menu</p>
  </div><!-- End Section Title -->

  <div class="container isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">

    <div class="row" data-aos="fade-up" data-aos-delay="100">
      <div class="col-lg-12 d-flex justify-content-center">
        <ul class="menu-filters isotope-filters">
          <li data-filter="*" class="filter-active">All</li>
          <li data-filter=".filter-starters">Starters</li>
          <li data-filter=".filter-salads">Salads</li>
          <li data-filter=".filter-specialty">Specialty</li>
        </ul>
      </div>
    </div><!-- Menu Filters -->

    <div class="row isotope-container" data-aos="fade-up" data-aos-delay="200">

      <div class="col-lg-6 menu-item isotope-item filter-starters">
        <img src="<?php echo e(asset('img/menu/lobster-bisque.jpg')); ?>" class="menu-img" alt="">
        <div class="menu-content">
          <a href="#">Lobster Bisque</a><span>$5.95</span>
        </div>
        <div class="menu-ingredients">
          Lorem, deren, trataro, filede, nerada
        </div>
      </div><!-- Menu Item -->

      <div class="col-lg-6 menu-item isotope-item filter-specialty">
        <img src="<?php echo e(asset('img/menu/bread-barrel.jpg')); ?>" class="menu-img" alt="">
        <div class="menu-content">
          <a href="#">Bread Barrel</a><span>$6.95</span>
        </div>
        <div class="menu-ingredients">
          Lorem, deren, trataro, filede, nerada
        </div>
      </div><!-- Menu Item -->

      <div class="col-lg-6 menu-item isotope-item filter-starters">
        <img src="<?php echo e(asset('img/menu/cake.jpg')); ?>" class="menu-img" alt="">
        <div class="menu-content">
          <a href="#">Crab Cake</a><span>$7.95</span>
        </div>
        <div class="menu-ingredients">
          A delicate crab cake served on a toasted roll with lettuce and tartar sauce
        </div>
      </div><!-- Menu Item -->

      <div class="col-lg-6 menu-item isotope-item filter-salads">
        <img src="<?php echo e(asset('img/menu/caesar.jpg')); ?>" class="menu-img" alt="">
        <div class="menu-content">
          <a href="#">Caesar Selections</a><span>$8.95</span>
        </div>
        <div class="menu-ingredients">
          Lorem, deren, trataro, filede, nerada
        </div>
      </div><!-- Menu Item -->

      <div class="col-lg-6 menu-item isotope-item filter-specialty">
        <img src="<?php echo e(asset('img/menu/tuscan-grilled.jpg')); ?>" class="menu-img" alt="">
        <div class="menu-content">
          <a href="#">Tuscan Grilled</a><span>$9.95</span>
        </div>
        <div class="menu-ingredients">
          Grilled chicken with provolone, artichoke hearts, and roasted red pesto
        </div>
      </div><!-- Menu Item -->

      <div class="col-lg-6 menu-item isotope-item filter-starters">
        <img src="<?php echo e(asset('img/menu/mozzarella.jpg')); ?>" class="menu-img" alt="">
        <div class="menu-content">
          <a href="#">Mozzarella Stick</a><span>$4.95</span>
        </div>
        <div class="menu-ingredients">
          Lorem, deren, trataro, filede, nerada
        </div>
      </div><!-- Menu Item -->

      <div class="col-lg-6 menu-item isotope-item filter-salads">
        <img src="<?php echo e(asset('img/menu/greek-salad.jpg')); ?>" class="menu-img" alt="">
        <div class="menu-content">
          <a href="#">Greek Salad</a><span>$9.95</span>
        </div>
        <div class="menu-ingredients">
          Fresh spinach, crisp romaine, tomatoes, and Greek olives
        </div>
      </div><!-- Menu Item -->

      <div class="col-lg-6 menu-item isotope-item filter-salads">
        <img src="<?php echo e(asset('img/menu/spinach-salad.jpg')); ?>" class="menu-img" alt="">
        <div class="menu-content">
          <a href="#">Spinach Salad</a><span>$9.95</span>
        </div>
        <div class="menu-ingredients">
          Fresh spinach with mushrooms, hard boiled egg, and warm bacon vinaigrette
        </div>
      </div><!-- Menu Item -->

      <div class="col-lg-6 menu-item isotope-item filter-specialty">
        <img src="<?php echo e(asset('img/menu/lobster-roll.jpg')); ?>" class="menu-img" alt="">
        <div class="menu-content">
          <a href="#">Lobster Roll</a><span>$12.95</span>
        </div>
        <div class="menu-ingredients">
          Plump lobster meat, mayo and crisp lettuce on a toasted bulky roll
        </div>
      </div><!-- Menu Item -->

    </div><!-- Menu Container -->

  </div>

</section><!-- /Menu Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mysite\mysite\resources\views/menu/index.blade.php ENDPATH**/ ?>